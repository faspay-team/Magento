<?php
 
namespace Faspay\Debit\Model\Payment;


class bcasakuku extends PaymentMethod
{


    protected $_code = 'bca_sakuku';


}