<?php
 
namespace Faspay\Debit\Model\Payment;


class tcash extends PaymentMethod
{


    protected $_code = 't_cash';


}