<?php
 
namespace Faspay\Debit\Model\Payment;


class mandiriecash extends PaymentMethod
{


    protected $_code = 'mandiri_ecash';


}