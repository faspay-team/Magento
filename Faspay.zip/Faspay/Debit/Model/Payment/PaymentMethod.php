<?php
 
namespace Faspay\Debit\Model\Payment;

class PaymentMethod extends \Magento\Payment\Model\Method\AbstractMethod
{

    protected $_code = 'custompayment';

}