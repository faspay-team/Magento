<?php
 
namespace Faspay\Debit\Model\Payment;


class brimocash extends PaymentMethod
{


    protected $_code = 'bri_mocash';


}