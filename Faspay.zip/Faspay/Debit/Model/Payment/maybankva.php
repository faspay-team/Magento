<?php
 
namespace Faspay\Debit\Model\Payment;


class maybankva extends PaymentMethod
{


    protected $_code = 'maybank_va';


}