<?php
 
namespace Faspay\Debit\Model\Payment;


class bcaklikpay extends PaymentMethod
{


    protected $_code = 'bca_klikpay';


}