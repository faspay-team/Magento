<?php
 
namespace Faspay\Debit\Model\Payment;


class alfagroup extends PaymentMethod
{


    protected $_code = 'alfagroup';


}