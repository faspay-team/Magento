<?php
 
namespace Faspay\Debit\Model\Payment;


class indomaretpoint extends PaymentMethod
{


    protected $_code = 'indomaret_point';


}