<?php
 
namespace Faspay\Debit\Model\Payment;


class briepay extends PaymentMethod
{


    protected $_code = 'bri_epay';


}