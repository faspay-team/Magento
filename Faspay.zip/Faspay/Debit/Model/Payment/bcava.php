<?php
 
namespace Faspay\Debit\Model\Payment;


class bcava extends PaymentMethod
{


    protected $_code = 'bca_va';


}