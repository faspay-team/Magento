<?php
 
namespace Faspay\Debit\Model\Payment;


class danamonva extends PaymentMethod
{


    protected $_code = 'danamon_va';


}