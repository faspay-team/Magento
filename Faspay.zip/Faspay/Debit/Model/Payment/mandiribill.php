<?php
 
namespace Faspay\Debit\Model\Payment;


class mandiribill extends PaymentMethod
{


    protected $_code = 'mandiri_bill';


}