<?php
 
namespace Faspay\Debit\Model\Payment;


class dana extends PaymentMethod
{


    protected $_code = 'dana';


}