<?php
 
namespace Faspay\Debit\Model\Payment;


class permatanet extends PaymentMethod
{


    protected $_code = 'permata_net';


}