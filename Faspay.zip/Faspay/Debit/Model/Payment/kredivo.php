<?php
 
namespace Faspay\Debit\Model\Payment;


class kredivo extends PaymentMethod
{


    protected $_code = 'kredivo';


}