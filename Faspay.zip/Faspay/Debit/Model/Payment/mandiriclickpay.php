<?php
 
namespace Faspay\Debit\Model\Payment;


class mandiriclickpay extends PaymentMethod
{


    protected $_code = 'mandiri_clickpay';


}