<?php
 
namespace Faspay\Debit\Model\Payment;


class ovo extends PaymentMethod
{


    protected $_code = 'ovo';


}