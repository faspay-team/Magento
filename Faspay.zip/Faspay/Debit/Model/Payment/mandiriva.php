<?php
 
namespace Faspay\Debit\Model\Payment;


class mandiriva extends PaymentMethod
{


    protected $_code = 'mandiri_va';


}