<?php
 
namespace Faspay\Debit\Model\Payment;


class akulaku extends PaymentMethod
{


    protected $_code = 'akulaku';


}