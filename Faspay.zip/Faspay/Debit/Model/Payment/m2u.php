<?php
 
namespace Faspay\Debit\Model\Payment;


class m2u extends PaymentMethod
{


    protected $_code = 'm2u';


}