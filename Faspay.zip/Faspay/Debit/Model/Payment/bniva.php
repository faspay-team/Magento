<?php
 
namespace Faspay\Debit\Model\Payment;


class bniva extends PaymentMethod
{


    protected $_code = 'bni_va';


}