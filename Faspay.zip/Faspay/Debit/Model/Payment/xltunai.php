<?php
 
namespace Faspay\Debit\Model\Payment;


class xltunai extends PaymentMethod
{


    protected $_code = 'xl_tunai';


}