<?php
 
namespace Faspay\Debit\Model\Payment;


class shopeeapp extends PaymentMethod
{


    protected $_code = 'shopee_app';


}