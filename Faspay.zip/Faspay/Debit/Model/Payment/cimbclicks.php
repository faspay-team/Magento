<?php
 
namespace Faspay\Debit\Model\Payment;


class cimbclicks extends PaymentMethod
{


    protected $_code = 'cimb_clicks';


}