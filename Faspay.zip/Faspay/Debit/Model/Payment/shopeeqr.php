<?php
 
namespace Faspay\Debit\Model\Payment;


class shopeeqr extends PaymentMethod
{


    protected $_code = 'shopee_qr';


}