<?php
 
namespace Faspay\Debit\Model\Payment;


class briva extends PaymentMethod
{


    protected $_code = 'bri_va';


}