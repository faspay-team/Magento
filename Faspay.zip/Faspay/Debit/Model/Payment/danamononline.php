<?php
 
namespace Faspay\Debit\Model\Payment;


class danamononline extends PaymentMethod
{


    protected $_code = 'danamon_online';


}