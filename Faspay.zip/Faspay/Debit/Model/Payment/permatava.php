<?php
 
namespace Faspay\Debit\Model\Payment;
 

class permatava extends PaymentMethod
{

    protected $_code = 'permata_va';
}