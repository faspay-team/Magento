<?php
 
namespace Faspay\Credit\Model\Payment;



class mid3 extends PaymentMethod
{


    protected $_code = 'mid_3';


}