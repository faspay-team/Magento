<?php
 
namespace Faspay\Credit\Model\Payment;


class mid15 extends PaymentMethod
{

    protected $_code = 'mid_15';

}