<?php
 
namespace Faspay\Credit\Model\Payment;



class mid13 extends PaymentMethod
{


    protected $_code = 'mid_13';


}