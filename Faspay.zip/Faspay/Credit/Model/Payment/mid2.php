<?php
 
namespace Faspay\Credit\Model\Payment;



class mid2 extends PaymentMethod
{


    protected $_code = 'mid_2';


}