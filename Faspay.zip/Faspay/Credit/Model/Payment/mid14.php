<?php
 
namespace Faspay\Credit\Model\Payment;


class mid14 extends PaymentMethod
{

    protected $_code = 'mid_14';

}