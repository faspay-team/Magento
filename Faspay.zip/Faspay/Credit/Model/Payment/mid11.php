<?php
 
namespace Faspay\Credit\Model\Payment;



class mid11 extends PaymentMethod
{


    protected $_code = 'mid_11';


}