<?php
 
namespace Faspay\Credit\Model\Payment;



class mid1 extends PaymentMethod
{


    protected $_code = 'mid_1';


}