<?php
 
namespace Faspay\Credit\Model\Payment;



class mid12 extends PaymentMethod
{


    protected $_code = 'mid_12';


}