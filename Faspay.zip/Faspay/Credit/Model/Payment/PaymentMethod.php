<?php
 
namespace Faspay\Credit\Model\Payment;

class PaymentMethod extends \Magento\Payment\Model\Method\AbstractMethod
{

    protected $_code = 'creditpayment';

}