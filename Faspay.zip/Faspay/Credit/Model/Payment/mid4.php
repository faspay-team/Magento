<?php
 
namespace Faspay\Credit\Model\Payment;



class mid4 extends PaymentMethod
{


    protected $_code = 'mid_4';


}